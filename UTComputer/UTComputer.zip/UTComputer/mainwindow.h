#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDialog>

#include "calculator.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow, public Calculator
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    QDialog* editProgrammDialog;
    QDialog* editVariablesDialog;
};

#endif // MAINWINDOW_H
