//#include <QtTest/QtTest>

//#include "../number.h"

//class TestNumber : public QObject {
//    Q_OBJECT

//private slots:
//    void operation_data();
//    void operation();
//};

//void TestNumber::operation_data(){
//    QTest::addColumn<Number>("operation");
//    QTest::addColumn<Number>("result");

//    Number i = 2,
//           x = 3.5;

//    QTest::newRow("1") << (i + i) << 4;
//}

//void TestNumber::operation(){
//    QFETCH(Number, operation);
//    QFETCH(Number, result);

//    QCOMPARE(operation, result);
//}

//QTEST_MAIN(TestNumber)
//#include "tests.moc"
